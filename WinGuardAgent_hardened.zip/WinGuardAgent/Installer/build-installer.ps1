$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
& "$root\publish.ps1"
dotnet build "$root\Installer\WinGuardAgent.wixproj" -c Release
