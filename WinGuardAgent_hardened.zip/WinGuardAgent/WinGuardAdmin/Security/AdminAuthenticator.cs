using System.Runtime.InteropServices;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;
using WinGuardAgent;

namespace WinGuardAdmin.Security;

public sealed record AdminAuthenticationResult(bool Success, string Message, string? Sid = null, string? DisplayName = null);

public static class AdminAuthenticator
{
    private const int LOGON32_LOGON_INTERACTIVE = 2;
    private const int LOGON32_PROVIDER_DEFAULT = 0;
    private static readonly string AuthorizedAdminFile = Path.Combine(Paths.ProgramData, "authorized-admin.sid");

    public static AdminAuthenticationResult Authenticate(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(password))
            return new(false, "Enter the administrator username and current Windows password.");

        ParseUsername(username.Trim(), out var domain, out var user);
        if (!LogonUser(user, domain, password, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, out var token))
            return new(false, "Windows rejected those credentials. Use the account's current Windows password, not a WinGuard password.");

        using (token)
        {
            using var identity = new WindowsIdentity(token.DangerousGetHandle());
            var principal = new WindowsPrincipal(identity);
            if (!principal.IsInRole(WindowsBuiltInRole.Administrator))
                return new(false, "That Windows account is not an administrator.");

            var sid = identity.User?.Value;
            if (string.IsNullOrWhiteSpace(sid))
                return new(false, "WinGuard could not read the administrator account SID.");

            Directory.CreateDirectory(Paths.ProgramData);
            if (File.Exists(AuthorizedAdminFile))
            {
                var authorizedSid = File.ReadAllText(AuthorizedAdminFile).Trim();
                if (!string.Equals(authorizedSid, sid, StringComparison.OrdinalIgnoreCase))
                    return new(false, "This WinGuard installation is locked to a different administrator account.");
            }
            else
            {
                File.WriteAllText(AuthorizedAdminFile, sid);
            }

            return new(true, "Authenticated", sid, identity.Name);
        }
    }

    private static void ParseUsername(string input, out string? domain, out string user)
    {
        if (input.Contains('\\'))
        {
            var parts = input.Split('\\', 2);
            domain = parts[0] == "." ? Environment.MachineName : parts[0];
            user = parts[1];
        }
        else if (input.Contains('@'))
        {
            // Microsoft accounts can be entered as MicrosoftAccount\email@example.com.
            domain = null;
            user = input;
        }
        else
        {
            domain = Environment.MachineName;
            user = input;
        }
    }

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool LogonUser(
        string lpszUsername,
        string? lpszDomain,
        string lpszPassword,
        int dwLogonType,
        int dwLogonProvider,
        out SafeAccessTokenHandle phToken);
}
