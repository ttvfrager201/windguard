using System.Windows;
using System.Windows.Input;
using WinGuardAdmin.Security;

namespace WinGuardAdmin;

public partial class LoginWindow : Window
{
    public string? AuthenticatedAdminName { get; private set; }

    public LoginWindow()
    {
        InitializeComponent();
        UsernameBox.Text = $"{Environment.MachineName}\\";
        UsernameBox.Focus();
        UsernameBox.CaretIndex = UsernameBox.Text.Length;
    }

    private void Unlock_Click(object sender, RoutedEventArgs e) => TryUnlock();
    private void PasswordBox_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) TryUnlock(); }
    private void Cancel_Click(object sender, RoutedEventArgs e) { DialogResult = false; Close(); }

    private void TryUnlock()
    {
        ErrorText.Text = string.Empty;
        var result = AdminAuthenticator.Authenticate(UsernameBox.Text, PasswordBox.Password);
        PasswordBox.Clear();
        if (!result.Success)
        {
            ErrorText.Text = result.Message;
            PasswordBox.Focus();
            return;
        }

        AuthenticatedAdminName = result.DisplayName;
        DialogResult = true;
        Close();
    }
}
