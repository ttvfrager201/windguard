using System.Windows;
using WinGuardAdmin.Security;
using WinGuardAgent.Security;

namespace WinGuardAdmin;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        if (!SecurityHardening.IsAdministrator())
        {
            MessageBox.Show("WinGuard Admin must run with administrator privileges.", "WinGuard Admin", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(5);
            return;
        }

        var login = new LoginWindow();
        if (login.ShowDialog() != true)
        {
            Shutdown(0);
            return;
        }

        var main = new MainWindow(login.AuthenticatedAdminName ?? "Administrator");
        MainWindow = main;
        main.Show();
    }
}
