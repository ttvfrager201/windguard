using System.ServiceProcess;
using System.Windows;
using System.Windows.Controls;
using WinGuardAgent;
using WinGuardAgent.Chrome;
using WinGuardAgent.Network;
using WinGuardAgent.Storage;

namespace WinGuardAdmin;

public partial class MainWindow : Window
{
    private readonly Database _db = new();
    private readonly PolicyRepository _policies;
    private readonly EventRepository _events;
    private readonly SettingsRepository _settings;
    private readonly AgentStatusRepository _status;
    private readonly string _adminName;

    public MainWindow(string adminName)
    {
        InitializeComponent();
        _adminName = adminName;
        _policies = new PolicyRepository(_db);
        _events = new EventRepository(_db);
        _settings = new SettingsRepository(_db);
        _status = new AgentStatusRepository(_db);

        AdminIdentityText.Text = $"Unlocked by {_adminName}";
        DomainCategoryBox.ItemsSource = Enum.GetValues<PolicyCategory>();
        AppCategoryBox.ItemsSource = Enum.GetValues<PolicyCategory>();
        DomainCategoryBox.SelectedItem = PolicyCategory.Custom;
        AppCategoryBox.SelectedItem = PolicyCategory.Custom;
        Loaded += async (_, _) => await RefreshAllAsync();
    }

    private async Task RefreshAllAsync()
    {
        try
        {
            await _db.InitializeAsync();
            await RefreshServiceStatusAsync();
            await RefreshDomainsAsync();
            await RefreshAppsAsync();
            await LoadSettingsAsync();
            await RefreshEventsAsync();
            FooterText.Text = $"Data: {Paths.ProgramData}";
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private async Task RefreshServiceStatusAsync()
    {
        string service;
        try
        {
            using var sc = new ServiceController(Constants.ServiceName);
            sc.Refresh();
            service = sc.Status.ToString();
        }
        catch { service = "Not installed"; }

        var status = await _status.GetAsync();
        ServiceStatusText.Text = status is null ? $"Service: {service}" : $"Service: {service} · Agent: {status.Value.State}";
    }

    private async Task RefreshDomainsAsync()
    {
        DomainsGrid.ItemsSource = (await _policies.GetDomainRulesAsync())
            .OrderBy(x => x.IsAllowed).ThenBy(x => x.Domain)
            .Select(x => new DomainRow(x.Id, x.Domain, x.IsAllowed ? "ALLOW" : "BLOCK", x.IsAllowed, x.Category, x.Source))
            .ToList();
    }

    private async Task RefreshAppsAsync() => AppsGrid.ItemsSource = (await _policies.GetApplicationRulesAsync()).OrderBy(x => x.ExecutableName).ToList();

    private async Task RefreshEventsAsync()
    {
        EventsGrid.ItemsSource = (await _events.RecentAsync(250))
            .Select(x => new EventRow(x.Timestamp.ToLocalTime().ToString("g"), x.Type, x.Username ?? "", x.Subject ?? "", x.Reason ?? ""))
            .ToList();
    }

    private async Task LoadSettingsAsync()
    {
        var cfg = await _settings.GetConfigAsync();
        ChromePoliciesCheck.IsChecked = cfg.ChromePoliciesEnabled;
        DnsProtectionCheck.IsChecked = cfg.DnsProtectionEnabled;
        SafeSearchCheck.IsChecked = cfg.ForceGoogleSafeSearch;
        UnauthorizedExtensionsCheck.IsChecked = cfg.BlockUnauthorizedExtensions;
        RestrictWebStoreCheck.IsChecked = cfg.RestrictChromeWebStore;
        FriendlyPageCheck.IsChecked = cfg.FriendlyBlockPageEnabled;
        BlockMessageBox.Text = cfg.FriendlyBlockPageMessage;

        CategoryPanel.Children.Clear();
        foreach (var category in Enum.GetValues<PolicyCategory>())
        {
            CategoryPanel.Children.Add(new CheckBox
            {
                Content = category.ToString(),
                Tag = category,
                IsChecked = cfg.BlockedCategories.Contains(category),
                Width = 230,
                Margin = new Thickness(4, 7, 4, 7)
            });
        }
    }

    private async void BlockDomain_Click(object sender, RoutedEventArgs e)
    {
        await RunUiActionAsync(async () =>
        {
            var domain = DomainBox.Text.Trim();
            var category = (PolicyCategory)(DomainCategoryBox.SelectedItem ?? PolicyCategory.Custom);
            await _policies.AddDomainAsync(domain, false, category);
            await _events.WriteAsync("policy_changed", username: _adminName, subject: domain, reason: $"Domain blocked ({category})");
            await ApplyChromeAsync();
            DomainBox.Clear();
            await RefreshDomainsAsync();
        }, "Domain blocked.");
    }

    private async void AllowDomain_Click(object sender, RoutedEventArgs e)
    {
        await RunUiActionAsync(async () =>
        {
            var domain = DomainBox.Text.Trim();
            await _policies.AddDomainAsync(domain, true);
            await _events.WriteAsync("policy_changed", username: _adminName, subject: domain, reason: "Domain allowed");
            await ApplyChromeAsync();
            DomainBox.Clear();
            await RefreshDomainsAsync();
        }, "Domain allowed.");
    }

    private async void RemoveDomain_Click(object sender, RoutedEventArgs e)
    {
        if (DomainsGrid.SelectedItem is not DomainRow row) return;
        await RunUiActionAsync(async () =>
        {
            await _policies.RemoveDomainAsync(row.Domain, row.IsAllowed);
            await _events.WriteAsync("policy_changed", username: _adminName, subject: row.Domain, reason: "Domain rule removed");
            await ApplyChromeAsync();
            await RefreshDomainsAsync();
        }, "Rule removed.");
    }

    private async void BlockApp_Click(object sender, RoutedEventArgs e)
    {
        await RunUiActionAsync(async () =>
        {
            var exe = AppBox.Text.Trim();
            var category = (PolicyCategory)(AppCategoryBox.SelectedItem ?? PolicyCategory.Custom);
            await _policies.AddApplicationAsync(exe, category: category);
            await _events.WriteAsync("policy_changed", username: _adminName, subject: exe, reason: $"Application blocked ({category})");
            AppBox.Clear();
            await RefreshAppsAsync();
        }, "Application blocked.");
    }

    private async void UnblockApp_Click(object sender, RoutedEventArgs e)
    {
        if (AppsGrid.SelectedItem is not ApplicationRule app) return;
        await RunUiActionAsync(async () =>
        {
            await _policies.RemoveApplicationAsync(app.ExecutableName);
            await _events.WriteAsync("policy_changed", username: _adminName, subject: app.ExecutableName, reason: "Application unblocked");
            await RefreshAppsAsync();
        }, "Application unblocked.");
    }

    private async void SaveSettings_Click(object sender, RoutedEventArgs e)
    {
        await RunUiActionAsync(async () =>
        {
            var old = await _settings.GetConfigAsync();
            var cfg = await _settings.GetConfigAsync();
            cfg.ChromePoliciesEnabled = ChromePoliciesCheck.IsChecked == true;
            cfg.DnsProtectionEnabled = DnsProtectionCheck.IsChecked == true;
            cfg.ForceGoogleSafeSearch = SafeSearchCheck.IsChecked == true;
            cfg.BlockUnauthorizedExtensions = UnauthorizedExtensionsCheck.IsChecked == true;
            cfg.RestrictChromeWebStore = RestrictWebStoreCheck.IsChecked == true;
            cfg.FriendlyBlockPageEnabled = FriendlyPageCheck.IsChecked == true;
            cfg.FriendlyBlockPageMessage = BlockMessageBox.Text.Trim();
            if (cfg.FriendlyBlockPageMessage.Length is < 1 or > 160)
                throw new ArgumentException("The blocked-page message must be 1 to 160 characters.");

            cfg.BlockedCategories = CategoryPanel.Children.OfType<CheckBox>()
                .Where(x => x.IsChecked == true && x.Tag is PolicyCategory)
                .Select(x => (PolicyCategory)x.Tag)
                .ToHashSet();

            await _settings.SaveConfigAsync(cfg);
            await _events.WriteAsync("policy_changed", username: _adminName, subject: "WinGuard settings", reason: "Settings changed from admin dashboard");
            if (cfg.ChromePoliciesEnabled) await ApplyChromeAsync();

            if (old.DnsProtectionEnabled != cfg.DnsProtectionEnabled)
            {
                if (!cfg.DnsProtectionEnabled) await NetworkProtectionManager.ConfigureLoopbackDnsAsync(false);
                RestartServiceBestEffort();
                if (cfg.DnsProtectionEnabled) await NetworkProtectionManager.ConfigureLoopbackDnsAsync(true);
            }
            else if (old.FriendlyBlockPageEnabled != cfg.FriendlyBlockPageEnabled || old.FriendlyBlockPageMessage != cfg.FriendlyBlockPageMessage)
            {
                RestartServiceBestEffort();
            }
            await RefreshServiceStatusAsync();
        }, "Settings saved.");
    }

    private async Task ApplyChromeAsync()
    {
        var cfg = await _settings.GetConfigAsync();
        if (cfg.ChromePoliciesEnabled)
            await new ChromePolicyManager(_policies, _events).ApplyAsync(cfg);
    }

    private async void StartService_Click(object sender, RoutedEventArgs e) => await RunUiActionAsync(() => ServiceActionAsync(true), "Service started.");
    private async void StopService_Click(object sender, RoutedEventArgs e) => await RunUiActionAsync(() => ServiceActionAsync(false), "Service stopped.");
    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshAllAsync();
    private async void RefreshEvents_Click(object sender, RoutedEventArgs e) => await RefreshEventsAsync();

    private async Task ServiceActionAsync(bool start)
    {
        await Task.Run(() =>
        {
            using var sc = new ServiceController(Constants.ServiceName);
            sc.Refresh();
            if (start && sc.Status != ServiceControllerStatus.Running)
            {
                sc.Start();
                sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(15));
            }
            else if (!start && sc.Status != ServiceControllerStatus.Stopped)
            {
                sc.Stop();
                sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(15));
            }
        });
        await RefreshServiceStatusAsync();
    }

    private static void RestartServiceBestEffort()
    {
        try
        {
            using var sc = new ServiceController(Constants.ServiceName);
            sc.Refresh();
            if (sc.Status != ServiceControllerStatus.Stopped)
            {
                sc.Stop();
                sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(15));
            }
            sc.Start();
            sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(15));
        }
        catch { }
    }

    private async Task RunUiActionAsync(Func<Task> action, string success)
    {
        try
        {
            IsEnabled = false;
            await action();
            FooterText.Text = success;
        }
        catch (Exception ex) { ShowError(ex); }
        finally { IsEnabled = true; }
    }

    private void ShowError(Exception ex)
    {
        FooterText.Text = ex.Message;
        MessageBox.Show(ex.Message, "WinGuard Admin", MessageBoxButton.OK, MessageBoxImage.Error);
    }

    private sealed record DomainRow(long Id, string Domain, string RuleType, bool IsAllowed, PolicyCategory Category, string Source);
    private sealed record EventRow(string LocalTime, string Type, string Username, string Subject, string Reason);
}
