using Microsoft.Win32;
using WinGuardAgent.Storage;

namespace WinGuardAgent.Chrome;

// Keeps the historical class name for compatibility, but applies equivalent
// machine-level policies to both Chrome and Microsoft Edge when configured.
public sealed class ChromePolicyManager(PolicyRepository policies, EventRepository events)
{
    private const string ChromeKey=@"SOFTWARE\Policies\Google\Chrome";
    private const string EdgeKey=@"SOFTWARE\Policies\Microsoft\Edge";

    public async Task ApplyAsync(AgentConfig cfg, bool writeAudit = true)
    {
        var rules=await policies.GetDomainRulesAsync();
        var blocked=rules.Where(x=>!x.IsAllowed).SelectMany(ToUrlPatterns).ToList();
        if(cfg.RestrictChromeWebStore)
        {
            blocked.Add("https://chromewebstore.google.com/*");
            blocked.Add("https://chrome.google.com/webstore/*");
        }
        var allowed=rules.Where(x=>x.IsAllowed).SelectMany(ToUrlPatterns).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();

        ApplyBrowserPolicies(ChromeKey,blocked,allowed,cfg,isChrome:true);
        if(cfg.ManageEdgePolicies)
            ApplyBrowserPolicies(EdgeKey,blocked,allowed,cfg,isChrome:false);

        if(writeAudit)
            await events.WriteAsync("policy_changed",subject:"Browsers",reason:"Chrome/Edge enterprise policies refreshed");
    }

    public bool CorePoliciesAppearIntact(AgentConfig cfg)
    {
        if(!CheckBrowser(ChromeKey,cfg)) return false;
        if(cfg.ManageEdgePolicies && !CheckBrowser(EdgeKey,cfg)) return false;
        return true;
    }

    private static bool CheckBrowser(string path, AgentConfig cfg)
    {
        using var root=Registry.LocalMachine.OpenSubKey(path,writable:false);
        if(root is null) return false;
        if(cfg.DisableBrowserDnsOverHttps && !string.Equals(root.GetValue("DnsOverHttpsMode") as string,"off",StringComparison.OrdinalIgnoreCase)) return false;
        if(cfg.LockSystemProxy && !string.Equals(root.GetValue("ProxyMode") as string,"direct",StringComparison.OrdinalIgnoreCase)) return false;
        return root.OpenSubKey("URLBlocklist") is not null && root.OpenSubKey("URLAllowlist") is not null;
    }

    private static void ApplyBrowserPolicies(string path, IEnumerable<string> blocked, IEnumerable<string> allowed, AgentConfig cfg, bool isChrome)
    {
        using var root=Registry.LocalMachine.CreateSubKey(path,writable:true) ?? throw new InvalidOperationException($"Cannot open browser policy registry key {path}.");
        WriteList(root,"URLBlocklist",blocked.Distinct(StringComparer.OrdinalIgnoreCase));
        WriteList(root,"URLAllowlist",allowed);
        root.SetValue("SafeBrowsingProtectionLevel",2,RegistryValueKind.DWord);
        if(isChrome) root.SetValue("ForceGoogleSafeSearch",cfg.ForceGoogleSafeSearch?1:0,RegistryValueKind.DWord);
        if(cfg.DisableBrowserDnsOverHttps) root.SetValue("DnsOverHttpsMode","off",RegistryValueKind.String);
        if(cfg.LockSystemProxy) root.SetValue("ProxyMode","direct",RegistryValueKind.String);
        if(cfg.BlockUnauthorizedExtensions) WriteList(root,"ExtensionInstallBlocklist",["*"]);
        else root.DeleteSubKeyTree("ExtensionInstallBlocklist",throwOnMissingSubKey:false);
    }

    private static IEnumerable<string> ToUrlPatterns(DomainRule rule)
    {
        var d=rule.Domain.Trim().TrimStart('.');
        if(d.Length==0) yield break;
        // Match both the exact host and subdomains.
        yield return $"*://{d}/*";
        yield return $"*://*.{d}/*";
    }

    public static void SetExtensionAllowlist(IEnumerable<string> ids)
    {
        var cleaned=ids.Select(x=>x.Trim()).Where(x=>x.Length>0).ToArray();
        using(var root=Registry.LocalMachine.CreateSubKey(ChromeKey,writable:true)!) WriteList(root,"ExtensionInstallAllowlist",cleaned);
        using(var root=Registry.LocalMachine.CreateSubKey(EdgeKey,writable:true)!) WriteList(root,"ExtensionInstallAllowlist",cleaned);
    }

    public static void SetExtensionBlocklist(IEnumerable<string> ids)
    {
        var cleaned=ids.Select(x=>x.Trim()).Where(x=>x.Length>0).ToArray();
        using(var root=Registry.LocalMachine.CreateSubKey(ChromeKey,writable:true)!) WriteList(root,"ExtensionInstallBlocklist",cleaned);
        using(var root=Registry.LocalMachine.CreateSubKey(EdgeKey,writable:true)!) WriteList(root,"ExtensionInstallBlocklist",cleaned);
    }

    private static void WriteList(RegistryKey root,string name,IEnumerable<string> values)
    {
        root.DeleteSubKeyTree(name,throwOnMissingSubKey:false);
        using var key=root.CreateSubKey(name,writable:true)!;
        var i=1;
        foreach(var value in values) key.SetValue((i++).ToString(),value,RegistryValueKind.String);
    }
}
