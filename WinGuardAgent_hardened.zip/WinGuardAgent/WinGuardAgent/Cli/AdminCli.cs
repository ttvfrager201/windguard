using System.Diagnostics;
using System.ServiceProcess;
using System.Text.Json;
using WinGuardAgent.Chrome;
using WinGuardAgent.Network;
using WinGuardAgent.Security;
using WinGuardAgent.Storage;

namespace WinGuardAgent.Cli;

public static class AdminCli
{
    public static async Task<int> RunAsync(string[] args)
    {
        var cmd=args[0].ToLowerInvariant();
        if(cmd is "help" or "--help" or "-h") { Help(); return 0; }
        if(!SecurityHardening.IsAdministrator()) { Console.Error.WriteLine("Administrator privileges are required. Open Terminal/PowerShell as Administrator."); return 5; }
        try
        {
            var db=new Database(); await db.InitializeAsync(); new SecurityHardening().EnsureProgramDataAcl(); var policies=new PolicyRepository(db); var events=new EventRepository(db); var settings=new SettingsRepository(db); var statusRepo=new AgentStatusRepository(db);
            switch(cmd)
            {
                case "install": await InstallAsync(); await events.WriteAsync("policy_changed",reason:"Agent installed"); break;
                case "uninstall": await UninstallAsync(); break;
                case "start": ServiceAction("start"); break;
                case "stop": ServiceAction("stop"); break;
                case "status": await PrintStatusAsync(statusRepo); break;
                case "block-domain": Require(args,2); await policies.AddDomainAsync(args[1],false,ParseCategory(args.Skip(2).FirstOrDefault())); await ApplyChromeAsync(policies,events,settings); Console.WriteLine($"Blocked {args[1]}"); break;
                case "allow-domain": Require(args,2); await policies.AddDomainAsync(args[1],true); await ApplyChromeAsync(policies,events,settings); Console.WriteLine($"Allowed {args[1]}"); break;
                case "unblock-domain": Require(args,2); await policies.RemoveDomainAsync(args[1],false); await ApplyChromeAsync(policies,events,settings); Console.WriteLine($"Unblocked {args[1]}"); break;
                case "unallow-domain": Require(args,2); await policies.RemoveDomainAsync(args[1],true); await ApplyChromeAsync(policies,events,settings); Console.WriteLine($"Removed allow rule for {args[1]}"); break;
                case "block-app": Require(args,2); await policies.AddApplicationAsync(args[1],category:ParseCategory(args.Skip(2).FirstOrDefault())); await events.WriteAsync("policy_changed",subject:args[1],reason:"Application blocked"); Console.WriteLine($"Blocked {args[1]}"); break;
                case "unblock-app": Require(args,2); await policies.RemoveApplicationAsync(args[1]); await events.WriteAsync("policy_changed",subject:args[1],reason:"Application unblocked"); Console.WriteLine($"Unblocked {args[1]}"); break;
                case "events": foreach(var e in await events.RecentAsync(args.Length>1&&int.TryParse(args[1],out var n)?n:100)) Console.WriteLine($"{e.Timestamp:u} {e.Type,-26} {e.Username,-24} {e.Subject,-35} {e.Reason}"); break;
                case "policy": await PrintPolicyAsync(policies,settings); break;
                case "dns-protection": Require(args,2); await SetDnsAsync(args[1],settings,events); break;
                case "block-page": Require(args,2); await SetBlockPageAsync(args[1],settings,events); break;
                case "block-message": Require(args,2); await SetBlockMessageAsync(string.Join(" ",args.Skip(1)),settings,events); break;
                case "category": Require(args,3); await SetCategoryAsync(args[1],args[2],settings,events); break;
                case "extension-allow": Require(args,2); ChromePolicyManager.SetExtensionAllowlist(args.Skip(1)); await events.WriteAsync("policy_changed",subject:"Chrome extensions",reason:"Allowlist updated"); break;
                case "extension-block": Require(args,2); ChromePolicyManager.SetExtensionBlocklist(args.Skip(1)); await events.WriteAsync("policy_changed",subject:"Chrome extensions",reason:"Blocklist updated"); break;
                case "import-blocklist": Require(args,2); var count=await new WinGuardAgent.Agent.UpdateManager(policies,events).ImportBlocklistAsync(args[1]); await ApplyChromeAsync(policies,events,settings); Console.WriteLine($"Imported {count} domain rules."); break;
                default: Console.Error.WriteLine($"Unknown command: {cmd}"); Help(); return 2;
            }
            return 0;
        }
        catch(Exception ex) { Console.Error.WriteLine(ex.Message); return 1; }
    }

    private static async Task ApplyChromeAsync(PolicyRepository p,EventRepository e,SettingsRepository s) { var cfg=await s.GetConfigAsync(); if(cfg.ChromePoliciesEnabled) await new ChromePolicyManager(p,e).ApplyAsync(cfg); }
    private static PolicyCategory ParseCategory(string? raw)=>Enum.TryParse<PolicyCategory>(raw,true,out var c)?c:PolicyCategory.Custom;
    private static void Require(string[] a,int n) { if(a.Length<n) throw new ArgumentException("Missing command argument. Use 'WinGuardAgent.exe help'."); }

    private static async Task InstallAsync()
    {
        var exe=Environment.ProcessPath ?? throw new InvalidOperationException("Cannot determine executable path.");
        if(!File.Exists(exe)) throw new FileNotFoundException(exe);
        await RunAsync("sc.exe",$"create {Constants.ServiceName} binPath= \"\\\"{exe}\\\"\" start= auto DisplayName= \"{Constants.DisplayName}\"");
        await RunAsync("sc.exe",$"description {Constants.ServiceName} \"{Constants.Description}\"");
        await RunAsync("sc.exe",$"failure {Constants.ServiceName} reset= 86400 actions= restart/5000/restart/15000/restart/60000");
        await NetworkProtectionManager.EnsureFirewallRuleAsync(exe);
        ServiceAction("start"); Console.WriteLine("WinGuard Agent installed and started.");
    }
    private static async Task UninstallAsync() { try { ServiceAction("stop"); } catch { } await RunAsync("sc.exe",$"delete {Constants.ServiceName}"); Console.WriteLine("Service removed. ProgramData is intentionally retained; delete it manually if you also want to erase policy/event history."); }
    private static void ServiceAction(string action) { using var sc=new ServiceController(Constants.ServiceName); if(action=="start" && sc.Status!=ServiceControllerStatus.Running){sc.Start();sc.WaitForStatus(ServiceControllerStatus.Running,TimeSpan.FromSeconds(15));} else if(action=="stop"&&sc.Status!=ServiceControllerStatus.Stopped){sc.Stop();sc.WaitForStatus(ServiceControllerStatus.Stopped,TimeSpan.FromSeconds(15));} Console.WriteLine($"{Constants.ServiceName}: {sc.Status}"); }
    private static async Task PrintStatusAsync(AgentStatusRepository repo) { try { using var sc=new ServiceController(Constants.ServiceName); Console.WriteLine($"Service: {sc.Status}"); } catch { Console.WriteLine("Service: not installed"); } var st=await repo.GetAsync(); if(st is not null) Console.WriteLine($"Agent: {st.Value.State}, version {st.Value.Version}, heartbeat {st.Value.Heartbeat:u}{(st.Value.Error is null?string.Empty:", error: "+st.Value.Error)}"); Console.WriteLine($"Data: {Paths.ProgramData}"); Console.WriteLine($"Database: {Paths.Database}"); }
    private static async Task PrintPolicyAsync(PolicyRepository p,SettingsRepository s) { var cfg=await s.GetConfigAsync(); Console.WriteLine(JsonSerializer.Serialize(cfg,new JsonSerializerOptions{WriteIndented=true})); Console.WriteLine("\nDomains:"); foreach(var d in await p.GetDomainRulesAsync()) Console.WriteLine($"  {(d.IsAllowed?"ALLOW":"BLOCK"),5} {d.Domain,-35} {d.Category}"); Console.WriteLine("\nApplications:"); foreach(var a in await p.GetApplicationRulesAsync()) Console.WriteLine($"  BLOCK {a.ExecutableName,-30} {a.Reason}"); }

    private static async Task SetCategoryAsync(string category,string value,SettingsRepository s,EventRepository e)
    {
        if(!Enum.TryParse<PolicyCategory>(category,true,out var cat)) throw new ArgumentException($"Unknown category: {category}");
        var cfg=await s.GetConfigAsync();
        var enable=value.Equals("on",StringComparison.OrdinalIgnoreCase)||value.Equals("true",StringComparison.OrdinalIgnoreCase)||value.Equals("block",StringComparison.OrdinalIgnoreCase);
        if(enable) cfg.BlockedCategories.Add(cat); else cfg.BlockedCategories.Remove(cat);
        await s.SaveConfigAsync(cfg); await e.WriteAsync("policy_changed",subject:cat.ToString(),reason=enable?"category blocking enabled":"category blocking disabled");
        Console.WriteLine($"Category {cat}: {(enable?"blocked":"not blocked by category")}");
    }


    private static async Task SetBlockPageAsync(string value,SettingsRepository s,EventRepository e)
    {
        var enable=value.Equals("on",StringComparison.OrdinalIgnoreCase)||value.Equals("true",StringComparison.OrdinalIgnoreCase)||value.Equals("enable",StringComparison.OrdinalIgnoreCase);
        var cfg=await s.GetConfigAsync(); cfg.FriendlyBlockPageEnabled=enable; await s.SaveConfigAsync(cfg);
        await e.WriteAsync("policy_changed",subject:"Friendly block page",reason=enable?"enabled":"disabled");
        RestartServiceBestEffort();
        Console.WriteLine($"Friendly block page {(enable?"enabled":"disabled")}.");
    }

    private static async Task SetBlockMessageAsync(string message,SettingsRepository s,EventRepository e)
    {
        message=message.Trim();
        if(message.Length is < 1 or > 160) throw new ArgumentException("Block-page message must be 1 to 160 characters.");
        var cfg=await s.GetConfigAsync(); cfg.FriendlyBlockPageMessage=message; await s.SaveConfigAsync(cfg);
        await e.WriteAsync("policy_changed",subject:"Friendly block page",reason:"message updated");
        RestartServiceBestEffort();
        Console.WriteLine($"Block-page message set to: {message}");
    }

    private static void RestartServiceBestEffort()
    {
        try { ServiceAction("stop"); ServiceAction("start"); } catch { }
    }

    private static async Task SetDnsAsync(string value,SettingsRepository s,EventRepository e)
    {
        var enable=value.Equals("on",StringComparison.OrdinalIgnoreCase)||value.Equals("true",StringComparison.OrdinalIgnoreCase)||value.Equals("enable",StringComparison.OrdinalIgnoreCase);
        var cfg=await s.GetConfigAsync(); cfg.DnsProtectionEnabled=enable; await s.SaveConfigAsync(cfg);
        if(!enable) await NetworkProtectionManager.ConfigureLoopbackDnsAsync(false);
        try { ServiceAction("stop"); } catch { }
        try { ServiceAction("start"); } catch { }
        if(enable) await NetworkProtectionManager.ConfigureLoopbackDnsAsync(true);
        await e.WriteAsync("policy_changed",subject:"DNS protection",reason:enable?"enabled":"disabled");
        Console.WriteLine($"DNS protection {(enable?"enabled":"disabled")}. Service and adapter settings were refreshed.");
    }
    private static async Task RunAsync(string file,string arguments) { var psi=new ProcessStartInfo(file,arguments){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true}; using var p=Process.Start(psi)??throw new InvalidOperationException($"Unable to launch {file}"); await p.WaitForExitAsync(); var err=await p.StandardError.ReadToEndAsync(); if(p.ExitCode!=0 && !err.Contains("already exists",StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException(err.Length>0?err:$"{file} exited with {p.ExitCode}"); }
    private static void Help() => Console.WriteLine("""
WinGuard Agent administrator CLI
  WinGuardAgent.exe install | uninstall | start | stop | status
  WinGuardAgent.exe block-domain <domain> [Category]
  WinGuardAgent.exe unblock-domain <domain>
  WinGuardAgent.exe allow-domain <domain>
  WinGuardAgent.exe unallow-domain <domain>
  WinGuardAgent.exe block-app <name.exe> [Category]
  WinGuardAgent.exe unblock-app <name.exe>
  WinGuardAgent.exe dns-protection on|off
  WinGuardAgent.exe block-page on|off
  WinGuardAgent.exe block-message <message>
  WinGuardAgent.exe category <Category> on|off
  WinGuardAgent.exe extension-allow <extension-id> [more ids...]
  WinGuardAgent.exe extension-block <extension-id> [more ids...]
  WinGuardAgent.exe import-blocklist <file.json>
  WinGuardAgent.exe events [count]
  WinGuardAgent.exe policy
Categories: WebProxiesAnonymizers, VpnTunneling, AdultContent, Gambling, MalwarePhishing, CloudGaming, SocialMedia, Custom
""");
}
