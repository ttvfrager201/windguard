namespace WinGuardAgent;

public enum PolicyCategory
{
    WebProxiesAnonymizers,
    VpnTunneling,
    AdultContent,
    Gambling,
    MalwarePhishing,
    CloudGaming,
    SocialMedia,
    Custom
}

public sealed record DomainRule(long Id, string Domain, bool IsAllowed, PolicyCategory Category, bool Enabled, string Source);
public sealed record ApplicationRule(long Id, string ExecutableName, string? Path, bool Enabled, string Reason, PolicyCategory Category);
public sealed record AgentEvent(long Id, DateTimeOffset Timestamp, string Type, string? Username, string? Subject, string? Reason, string? MetadataJson);
public sealed record InstalledApplication(string Key, string Name, string? Publisher, string? Version, DateTimeOffset? InstallTimestamp, string? Path);

public sealed class AgentConfig
{
    public bool DnsProtectionEnabled { get; set; } = false;
    public bool ChromePoliciesEnabled { get; set; } = true;
    public bool LockSystemProxy { get; set; } = true;
    public string[] UpstreamDns { get; set; } = ["1.1.1.1", "1.0.0.1"];
    public int ProcessScanMilliseconds { get; set; } = 2000;
    public int InstalledAppScanMinutes { get; set; } = 15;
    public bool ForceGoogleSafeSearch { get; set; } = true;
    public bool BlockUnauthorizedExtensions { get; set; } = false;
    public bool RestrictChromeWebStore { get; set; } = false;
    public bool FriendlyBlockPageEnabled { get; set; } = true;
    public bool TamperProtectionEnabled { get; set; } = true;
    public int TamperCheckSeconds { get; set; } = 60;
    public bool ManageEdgePolicies { get; set; } = true;
    public bool DisableBrowserDnsOverHttps { get; set; } = true;
    public string FriendlyBlockPageMessage { get; set; } = "Go back to work 😼";
    public HashSet<PolicyCategory> BlockedCategories { get; set; } = Enum.GetValues<PolicyCategory>().ToHashSet();
}

public sealed class BlocklistDocument
{
    public string Source { get; set; } = "local-import";
    public string Version { get; set; } = "1";
    public DateTimeOffset? GeneratedUtc { get; set; }
    public List<BlocklistEntry> Entries { get; set; } = [];
}

public sealed class BlocklistEntry
{
    public string Domain { get; set; } = string.Empty;
    public bool Allowed { get; set; }
    public PolicyCategory Category { get; set; } = PolicyCategory.Custom;
}
