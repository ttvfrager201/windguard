using Microsoft.Win32;
using WinGuardAgent.Storage;

namespace WinGuardAgent.Apps;

public sealed class InstalledAppDetector(Database db, EventRepository events)
{
    public async Task ScanAsync()
    {
        var now=DateTimeOffset.UtcNow; foreach(var app in Enumerate())
        {
            await using var c=await db.OpenAsync(); await using var check=c.CreateCommand(); check.CommandText="SELECT 1 FROM InstalledApplications WHERE AppKey=$k"; check.Parameters.AddWithValue("$k",app.Key); var existed=await check.ExecuteScalarAsync()!=null;
            await using var cmd=c.CreateCommand(); cmd.CommandText="INSERT INTO InstalledApplications(AppKey,Name,Publisher,Version,InstallTimestampUtc,Path,FirstSeenUtc,LastSeenUtc) VALUES($k,$n,$p,$v,$i,$x,$f,$l) ON CONFLICT(AppKey) DO UPDATE SET Name=$n,Publisher=$p,Version=$v,InstallTimestampUtc=$i,Path=$x,LastSeenUtc=$l";
            cmd.Parameters.AddWithValue("$k",app.Key); cmd.Parameters.AddWithValue("$n",app.Name); cmd.Parameters.AddWithValue("$p",(object?)app.Publisher??DBNull.Value); cmd.Parameters.AddWithValue("$v",(object?)app.Version??DBNull.Value); cmd.Parameters.AddWithValue("$i",(object?)app.InstallTimestamp?.ToString("O")??DBNull.Value); cmd.Parameters.AddWithValue("$x",(object?)app.Path??DBNull.Value); cmd.Parameters.AddWithValue("$f",now.ToString("O")); cmd.Parameters.AddWithValue("$l",now.ToString("O")); await cmd.ExecuteNonQueryAsync();
            if(!existed) await events.WriteAsync("new_application_detected",subject:app.Name,reason:app.Publisher);
        }
    }

    private static IEnumerable<InstalledApplication> Enumerate()
    {
        foreach(var hive in new[]{RegistryHive.LocalMachine,RegistryHive.CurrentUser})
        foreach(var view in new[]{RegistryView.Registry64,RegistryView.Registry32})
        {
            RegistryKey? baseKey=null,uninstall=null; try { baseKey=RegistryKey.OpenBaseKey(hive,view); uninstall=baseKey.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"); if(uninstall is null) continue; foreach(var subName in uninstall.GetSubKeyNames()) { using var sub=uninstall.OpenSubKey(subName); var name=sub?.GetValue("DisplayName") as string; if(string.IsNullOrWhiteSpace(name)) continue; var publisher=sub!.GetValue("Publisher") as string; var version=sub.GetValue("DisplayVersion") as string; var path=sub.GetValue("InstallLocation") as string; DateTimeOffset? installed=null; var raw=sub.GetValue("InstallDate") as string; if(DateTime.TryParseExact(raw,"yyyyMMdd",null,System.Globalization.DateTimeStyles.None,out var d)) installed=new DateTimeOffset(d,TimeSpan.Zero); var key=$"{hive}:{view}:{subName}"; yield return new(key,name,publisher,version,installed,path); } } finally { uninstall?.Dispose(); baseKey?.Dispose(); }
        }
    }
}
