using System.Diagnostics;
using System.Runtime.InteropServices;
using WinGuardAgent.Agent;
using WinGuardAgent.Storage;

namespace WinGuardAgent.Apps;

public sealed class ProcessBlocker(PolicyEngine policies, EventRepository events)
{
    private readonly HashSet<int> _reported=new();
    public async Task ScanAsync()
    {
        foreach(var p in Process.GetProcesses())
        {
            try
            {
                if(p.Id<=4 || p.Id==Environment.ProcessId) continue;
                var file=p.ProcessName+".exe"; string? path=null; try { path=p.MainModule?.FileName; } catch { }
                var rule=policies.MatchApplication(file,path); if(rule is null) continue;
                var user=TryGetProcessUser(p.Id);
                p.Kill(entireProcessTree:true);
                if(_reported.Add(p.Id))
                {
                    if(rule.Category==PolicyCategory.VpnTunneling) await events.WriteAsync("vpn_application_detected",user,file,rule.Reason);
                    if(rule.Category==PolicyCategory.WebProxiesAnonymizers) await events.WriteAsync("proxy_attempt_detected",user,file,rule.Reason);
                    await events.WriteAsync("blocked_application",user,file,rule.Reason);
                }
            }
            catch { }
            finally { p.Dispose(); }
        }
        if(_reported.Count>5000) _reported.Clear();
    }

    private static string? TryGetProcessUser(int processId)
    {
        IntPtr h=OpenProcess(0x0400,false,processId); if(h==IntPtr.Zero) return null;
        try { if(!OpenProcessToken(h,0x0008,out var token)) return null; try { var len=0; GetTokenInformation(token,1,IntPtr.Zero,0,out len); var buf=Marshal.AllocHGlobal(len); try { if(!GetTokenInformation(token,1,buf,len,out _)) return null; var sid=Marshal.ReadIntPtr(buf); var name=new System.Text.StringBuilder(256); var domain=new System.Text.StringBuilder(256); uint n=256,d=256; if(LookupAccountSid(null,sid,name,ref n,domain,ref d,out _)) return $"{domain}\\{name}"; } finally { Marshal.FreeHGlobal(buf); } } finally { CloseHandle(token); } } finally { CloseHandle(h); } return null;
    }
    [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int id);
    [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr process,uint access,out IntPtr token);
    [DllImport("advapi32.dll",SetLastError=true)] static extern bool GetTokenInformation(IntPtr token,int cls,IntPtr info,int len,out int ret);
    [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool LookupAccountSid(string? system,IntPtr sid,System.Text.StringBuilder name,ref uint cchName,System.Text.StringBuilder domain,ref uint cchDomain,out int use);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
}
