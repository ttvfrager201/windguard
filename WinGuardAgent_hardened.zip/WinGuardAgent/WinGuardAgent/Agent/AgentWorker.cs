using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using WinGuardAgent.Apps;
using WinGuardAgent.Chrome;
using WinGuardAgent.Network;
using WinGuardAgent.Security;
using WinGuardAgent.Storage;

namespace WinGuardAgent.Agent;

public sealed class AgentWorker(Database db, PolicyEngine policies, EventRepository events, SettingsRepository settings, ChromePolicyManager chrome, ProcessBlocker processes, InstalledAppDetector apps, DnsFilterService dns, FriendlyBlockPageService blockPage, NetworkProtectionManager network, SecurityHardening security, TamperProtectionService tamper, AgentStatusRepository status, ILogger<AgentWorker> log) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await db.InitializeAsync(stoppingToken);
        security.EnsureProgramDataAcl();
        await policies.RefreshAsync();
        var cfg=await settings.GetConfigAsync();
        if(cfg.ChromePoliciesEnabled) await chrome.ApplyAsync(cfg);
        if(cfg.LockSystemProxy) network.ApplyProxyProtection();
        if(cfg.DnsProtectionEnabled)
        {
            await NetworkProtectionManager.ConfigureLoopbackDnsAsync(true);
            await NetworkProtectionManager.EnsureFirewallRuleAsync(Environment.ProcessPath!);
            if(cfg.FriendlyBlockPageEnabled) _ = blockPage.StartAsync(cfg,stoppingToken);
            _ = dns.StartAsync(cfg,stoppingToken);
        }
        await events.WriteAsync("agent_started",reason:"Windows service started");
        await status.SetAsync("running");
        log.LogInformation("WinGuard Agent started.");

        var nextAppScan=DateTimeOffset.MinValue;
        var nextHeartbeat=DateTimeOffset.MinValue;
        var nextTamperCheck=DateTimeOffset.MinValue;
        while(!stoppingToken.IsCancellationRequested)
        {
            try
            {
                // Reload config so administrator changes take effect without restarting the service.
                cfg=await settings.GetConfigAsync();
                await policies.RefreshAsync();
                await processes.ScanAsync();

                if(DateTimeOffset.UtcNow>=nextHeartbeat)
                {
                    await status.SetAsync("running");
                    nextHeartbeat=DateTimeOffset.UtcNow.AddSeconds(30);
                }

                if(DateTimeOffset.UtcNow>=nextTamperCheck)
                {
                    await tamper.VerifyAndRepairAsync(cfg);
                    nextTamperCheck=DateTimeOffset.UtcNow.AddSeconds(Math.Clamp(cfg.TamperCheckSeconds,15,3600));
                }

                if(DateTimeOffset.UtcNow>=nextAppScan)
                {
                    await apps.ScanAsync();
                    nextAppScan=DateTimeOffset.UtcNow.AddMinutes(Math.Max(1,cfg.InstalledAppScanMinutes));
                }
                await Task.Delay(Math.Clamp(cfg.ProcessScanMilliseconds,500,30000),stoppingToken);
            }
            catch(OperationCanceledException) when(stoppingToken.IsCancellationRequested) { break; }
            catch(Exception ex)
            {
                log.LogError(ex,"Agent loop error");
                await events.WriteAsync("enforcement_error",reason:"Agent loop error; service will retry");
                await Task.Delay(3000,stoppingToken);
            }
        }
        await events.WriteAsync("agent_stopped",reason:"Windows service stopped");
        await status.SetAsync("stopped");
    }
}
