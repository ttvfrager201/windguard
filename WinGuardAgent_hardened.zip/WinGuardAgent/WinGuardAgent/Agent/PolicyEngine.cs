using WinGuardAgent.Storage;

namespace WinGuardAgent.Agent;

public sealed class PolicyEngine(PolicyRepository repo, SettingsRepository settings)
{
    private volatile Snapshot _snapshot = new([], [], Enum.GetValues<PolicyCategory>().ToHashSet());
    public async Task RefreshAsync() { var cfg=await settings.GetConfigAsync(); _snapshot = new((await repo.GetDomainRulesAsync()).ToArray(), (await repo.GetApplicationRulesAsync()).ToArray(), cfg.BlockedCategories); }

    public bool IsDomainBlocked(string domain, out DomainRule? matched)
    {
        matched=null; domain=domain.TrimEnd('.').ToLowerInvariant();
        DomainRule? bestAllow=null, bestBlock=null;
        foreach(var r in _snapshot.Domains)
        {
            if (!DomainMatches(domain,r.Domain)) continue;
            if(!r.IsAllowed && !_snapshot.BlockedCategories.Contains(r.Category)) continue;
            if(r.IsAllowed && (bestAllow is null || r.Domain.Length>bestAllow.Domain.Length)) bestAllow=r;
            if(!r.IsAllowed && (bestBlock is null || r.Domain.Length>bestBlock.Domain.Length)) bestBlock=r;
        }
        if(bestAllow is not null && (bestBlock is null || bestAllow.Domain.Length>=bestBlock.Domain.Length)) return false;
        matched=bestBlock; return bestBlock is not null;
    }

    public ApplicationRule? MatchApplication(string fileName, string? fullPath)
    {
        foreach(var r in _snapshot.Apps)
        {
            if(!r.Enabled || !string.Equals(r.ExecutableName,fileName,StringComparison.OrdinalIgnoreCase)) continue;
            if(string.IsNullOrWhiteSpace(r.Path) || string.Equals(Path.GetFullPath(r.Path), fullPath, StringComparison.OrdinalIgnoreCase)) return r;
        }
        return null;
    }

    private static bool DomainMatches(string host,string rule) => host.Equals(rule,StringComparison.OrdinalIgnoreCase) || host.EndsWith("."+rule,StringComparison.OrdinalIgnoreCase);
    private sealed record Snapshot(DomainRule[] Domains, ApplicationRule[] Apps, HashSet<PolicyCategory> BlockedCategories);
}
