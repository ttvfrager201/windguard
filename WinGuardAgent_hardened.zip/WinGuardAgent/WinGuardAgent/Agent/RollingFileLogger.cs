using Microsoft.Extensions.Logging;

namespace WinGuardAgent.Agent;

public sealed class RollingFileLoggerProvider(string directory) : ILoggerProvider
{
    private readonly object _gate=new();
    public ILogger CreateLogger(string categoryName)=>new FileLogger(directory,categoryName,_gate);
    public void Dispose() { }
    private sealed class FileLogger(string directory,string category,object gate) : ILogger
    {
        public IDisposable? BeginScope<TState>(TState state) where TState:notnull => null;
        public bool IsEnabled(LogLevel level)=>level>=LogLevel.Information;
        public void Log<TState>(LogLevel level,EventId eventId,TState state,Exception? exception,Func<TState,Exception?,string> formatter)
        {
            if(!IsEnabled(level)) return; try { Directory.CreateDirectory(directory); var file=Path.Combine(directory,$"agent-{DateTime.UtcNow:yyyyMMdd}.log"); var line=$"{DateTimeOffset.UtcNow:o} [{level}] {category}: {formatter(state,exception)}{(exception is null?"":" | "+exception)}{Environment.NewLine}"; lock(gate) File.AppendAllText(file,line); } catch { }
        }
    }
}
