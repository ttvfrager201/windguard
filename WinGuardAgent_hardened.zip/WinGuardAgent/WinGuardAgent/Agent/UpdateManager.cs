using System.Text.Json;
using System.Text.Json.Serialization;
using WinGuardAgent.Storage;

namespace WinGuardAgent.Agent;

public sealed class UpdateManager(PolicyRepository policies, EventRepository events)
{
    private static readonly JsonSerializerOptions Json = CreateJson();
    private static JsonSerializerOptions CreateJson() { var o=new JsonSerializerOptions(JsonSerializerDefaults.Web) { PropertyNameCaseInsensitive=true }; o.Converters.Add(new JsonStringEnumConverter()); return o; }

    public async Task<int> ImportBlocklistAsync(string path)
    {
        if(!File.Exists(path)) throw new FileNotFoundException("Blocklist file not found.",path);
        await using var stream=File.OpenRead(path);
        var doc=await JsonSerializer.DeserializeAsync<BlocklistDocument>(stream,Json) ?? throw new InvalidDataException("Invalid blocklist JSON.");
        if(doc.Entries.Count>500_000) throw new InvalidDataException("Blocklist is unreasonably large.");
        var imported=0;
        foreach(var e in doc.Entries)
        {
            if(string.IsNullOrWhiteSpace(e.Domain)) continue;
            await policies.AddDomainAsync(e.Domain,e.Allowed,e.Category,doc.Source);
            imported++;
        }
        await events.WriteAsync("policy_changed",subject:doc.Source,reason:$"Imported blocklist version {doc.Version} ({imported} entries)");
        return imported;
    }
}
