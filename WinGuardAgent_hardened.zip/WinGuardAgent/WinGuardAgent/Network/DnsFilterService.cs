using System.Net;
using System.Net.Sockets;
using Microsoft.Extensions.Logging;
using WinGuardAgent.Agent;
using WinGuardAgent.Storage;

namespace WinGuardAgent.Network;

public sealed class DnsFilterService(PolicyEngine policies, EventRepository events, ILogger<DnsFilterService> log)
{
    public async Task StartAsync(AgentConfig cfg,CancellationToken ct)
    {
        using var listener=new UdpClient(new IPEndPoint(IPAddress.Loopback,53));
        log.LogInformation("DNS filter listening on 127.0.0.1:53");
        while(!ct.IsCancellationRequested)
        {
            try
            {
                var request=await listener.ReceiveAsync(ct); _=HandleAsync(listener,request,cfg,ct);
            }
            catch(OperationCanceledException) when(ct.IsCancellationRequested) { break; }
            catch(Exception ex) { log.LogError(ex,"DNS listener error"); await Task.Delay(1000,ct); }
        }
    }

    private async Task HandleAsync(UdpClient listener,UdpReceiveResult request,AgentConfig cfg,CancellationToken ct)
    {
        try
        {
            var question=TryReadQuestion(request.Buffer);
            if(question is not null && policies.IsDomainBlocked(question.Value.Name,out var rule))
            {
                // For plain HTTP, map the blocked hostname to WinGuard's loopback block-page server.
                // HTTPS is intentionally NOT intercepted: browsers will use their secure/admin-blocked fallback.
                var response = cfg.FriendlyBlockPageEnabled && question.Value.Type == 1
                    ? BuildLoopbackAResponse(request.Buffer, question.Value.QuestionEnd)
                    : BuildNxDomain(request.Buffer);

                await listener.SendAsync(response,request.RemoteEndPoint,ct);
                await events.WriteAsync("blocked_domain",subject:question.Value.Name,reason=rule?.Category.ToString());
                return;
            }

            foreach(var dns in cfg.UpstreamDns)
            {
                if(!IPAddress.TryParse(dns,out var ip)) continue;
                using var upstream=new UdpClient(ip.AddressFamily);
                upstream.Client.ReceiveTimeout=3000;
                await upstream.SendAsync(request.Buffer,request.Buffer.Length,new IPEndPoint(ip,53));
                using var timeout=CancellationTokenSource.CreateLinkedTokenSource(ct);
                timeout.CancelAfter(3000);
                try
                {
                    var r=await upstream.ReceiveAsync(timeout.Token);
                    await listener.SendAsync(r.Buffer,request.RemoteEndPoint,ct);
                    return;
                }
                catch(OperationCanceledException) when(!ct.IsCancellationRequested) { }
            }
        }
        catch(Exception ex) { log.LogDebug(ex,"DNS request failed"); }
    }

    private static (string Name, ushort Type, int QuestionEnd)? TryReadQuestion(byte[] b)
    {
        if(b.Length<17) return null;
        int p=12;
        var labels=new List<string>();
        while(p<b.Length)
        {
            int len=b[p++];
            if(len==0) break;
            if((len&0xC0)!=0 || p+len>b.Length) return null;
            labels.Add(System.Text.Encoding.ASCII.GetString(b,p,len));
            p+=len;
        }
        if(labels.Count==0 || p+4>b.Length) return null;
        var type=(ushort)((b[p]<<8)|b[p+1]);
        var end=p+4;
        return (string.Join('.',labels).ToLowerInvariant(),type,end);
    }

    private static byte[] BuildLoopbackAResponse(byte[] q, int questionEnd)
    {
        if(q.Length<12 || questionEnd>q.Length) return BuildNxDomain(q);

        var r=new byte[questionEnd+16];
        Buffer.BlockCopy(q,0,r,0,questionEnd);
        r[2]=(byte)(r[2]|0x80);       // QR = response
        r[3]=(byte)(r[3]&0xF0);       // RCODE = NOERROR
        r[6]=0; r[7]=1;               // ANCOUNT = 1
        r[8]=r[9]=r[10]=r[11]=0;      // NSCOUNT/ARCOUNT = 0

        var p=questionEnd;
        r[p++]=0xC0; r[p++]=0x0C;     // NAME pointer to original QNAME
        r[p++]=0x00; r[p++]=0x01;     // TYPE A
        r[p++]=0x00; r[p++]=0x01;     // CLASS IN
        r[p++]=0x00; r[p++]=0x00; r[p++]=0x00; r[p++]=0x00; // TTL 0
        r[p++]=0x00; r[p++]=0x04;     // RDLENGTH 4
        r[p++]=127; r[p++]=0; r[p++]=0; r[p++]=1;
        return r;
    }

    private static byte[] BuildNxDomain(byte[] q)
    {
        var r=(byte[])q.Clone();
        if(r.Length<12) return r;
        r[2]=(byte)((r[2]|0x80)&0xFB);
        r[3]=(byte)((r[3]&0xF0)|0x03);
        r[6]=r[7]=r[8]=r[9]=r[10]=r[11]=0;
        return r;
    }
}
