using Microsoft.Win32;
using System.Diagnostics;

namespace WinGuardAgent.Network;

public sealed class NetworkProtectionManager
{
    public void ApplyProxyProtection()
    {
        using var policy=Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings",writable:true);
        policy?.SetValue("ProxySettingsPerUser",0,RegistryValueKind.DWord);
        using var machine=Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings",writable:true);
        machine?.SetValue("ProxyEnable",0,RegistryValueKind.DWord);
        using var chrome=Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Policies\Google\Chrome",writable:true);
        chrome?.SetValue("ProxyMode","direct",RegistryValueKind.String);
        using var edge=Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Policies\Microsoft\Edge",writable:true);
        edge?.SetValue("ProxyMode","direct",RegistryValueKind.String);
    }

    public bool ProxyProtectionAppearsIntact()
    {
        using var policy=Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings");
        using var machine=Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings");
        return Convert.ToInt32(policy?.GetValue("ProxySettingsPerUser",1))==0 && Convert.ToInt32(machine?.GetValue("ProxyEnable",1))==0;
    }

    public static async Task ConfigureLoopbackDnsAsync(bool enable)
    {
        var script=enable
            ? "Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses ('127.0.0.1') -ErrorAction SilentlyContinue }"
            : "Get-NetAdapter | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses -ErrorAction SilentlyContinue }";
        await RunPowerShellAsync(script);
    }

    public static async Task<bool> IsLoopbackDnsConfiguredAsync()
    {
        const string script="$bad = Get-DnsClientServerAddress -AddressFamily IPv4 | Where-Object { $_.ServerAddresses.Count -gt 0 -and ($_.ServerAddresses -notcontains '127.0.0.1') }; if ($bad) { 'false' } else { 'true' }";
        var output=await RunPowerShellForOutputAsync(script);
        return string.Equals(output.Trim(),"true",StringComparison.OrdinalIgnoreCase);
    }

    public static async Task EnsureFirewallRuleAsync(string executablePath)
    {
        var escaped=executablePath.Replace("'","''");
        var script=$"if (-not (Get-NetFirewallRule -DisplayName 'WinGuard Agent DNS' -ErrorAction SilentlyContinue)) {{ New-NetFirewallRule -DisplayName 'WinGuard Agent DNS' -Direction Inbound -Action Allow -Program '{escaped}' -Protocol UDP -LocalPort 53 -Profile Any | Out-Null }}";
        await RunPowerShellAsync(script);
    }

    private static async Task RunPowerShellAsync(string command)
    {
        var (_,error,code)=await RunPowerShellCoreAsync(command);
        if(code!=0) throw new InvalidOperationException(error);
    }

    private static async Task<string> RunPowerShellForOutputAsync(string command)
    {
        var (output,error,code)=await RunPowerShellCoreAsync(command);
        if(code!=0) throw new InvalidOperationException(error);
        return output;
    }

    private static async Task<(string Output,string Error,int ExitCode)> RunPowerShellCoreAsync(string command)
    {
        var encoded=Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes(command));
        var psi=new ProcessStartInfo("powershell.exe",$"-NoProfile -NonInteractive -EncodedCommand {encoded}")
        {
            UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true
        };
        using var p=Process.Start(psi) ?? throw new InvalidOperationException("Unable to start PowerShell.");
        var outputTask=p.StandardOutput.ReadToEndAsync();
        var errorTask=p.StandardError.ReadToEndAsync();
        await p.WaitForExitAsync();
        return (await outputTask,await errorTask,p.ExitCode);
    }
}
