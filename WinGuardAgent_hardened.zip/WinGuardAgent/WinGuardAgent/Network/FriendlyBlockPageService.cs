using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Encodings.Web;
using Microsoft.Extensions.Logging;
using WinGuardAgent.Agent;

namespace WinGuardAgent.Network;

/// <summary>
/// Small loopback-only HTTP server used when DNS protection maps a blocked HTTP site to 127.0.0.1.
/// It never proxies traffic and never decrypts HTTPS.
/// </summary>
public sealed class FriendlyBlockPageService(PolicyEngine policies, ILogger<FriendlyBlockPageService> log)
{
    public async Task StartAsync(AgentConfig cfg, CancellationToken ct)
    {
        if (!cfg.FriendlyBlockPageEnabled) return;

        var listener = new TcpListener(IPAddress.Loopback, 80);
        try
        {
            listener.Start(32);
            log.LogInformation("Friendly block page listening on http://127.0.0.1:80");
        }
        catch (SocketException ex)
        {
            log.LogWarning(ex, "Friendly block page could not bind TCP port 80. Plain HTTP sites will fall back to the browser/network error page.");
            return;
        }

        using (listener)
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    var client = await listener.AcceptTcpClientAsync(ct);
                    _ = HandleClientAsync(client, cfg, ct);
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested) { break; }
                catch (Exception ex)
                {
                    log.LogDebug(ex, "Friendly block page accept failed");
                }
            }
        }
    }

    private async Task HandleClientAsync(TcpClient client, AgentConfig cfg, CancellationToken ct)
    {
        using (client)
        {
            client.ReceiveTimeout = 3000;
            client.SendTimeout = 3000;
            await using var stream = client.GetStream();
            using var reader = new StreamReader(stream, Encoding.ASCII, false, 1024, leaveOpen: true);

            string host = "blocked site";
            try
            {
                var requestLine = await reader.ReadLineAsync(ct);
                if (string.IsNullOrWhiteSpace(requestLine)) return;

                for (var i = 0; i < 64; i++)
                {
                    var line = await reader.ReadLineAsync(ct);
                    if (string.IsNullOrEmpty(line)) break;
                    if (line.StartsWith("Host:", StringComparison.OrdinalIgnoreCase))
                    {
                        host = line[5..].Trim();
                        var colon = host.IndexOf(':');
                        if (colon >= 0) host = host[..colon];
                    }
                }
            }
            catch { return; }

            var category = "Administrator policy";
            if (policies.IsDomainBlocked(host, out var rule) && rule is not null)
                category = rule.Category.ToString();

            var html = BuildHtml(host, category, cfg.FriendlyBlockPageMessage);
            var body = Encoding.UTF8.GetBytes(html);
            var header = Encoding.ASCII.GetBytes(
                "HTTP/1.1 451 Unavailable For Legal Reasons\r\n" +
                "Content-Type: text/html; charset=utf-8\r\n" +
                $"Content-Length: {body.Length}\r\n" +
                "Cache-Control: no-store, no-cache, must-revalidate\r\n" +
                "Pragma: no-cache\r\n" +
                "X-Content-Type-Options: nosniff\r\n" +
                "Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline';\r\n" +
                "Connection: close\r\n\r\n");

            try
            {
                await stream.WriteAsync(header, ct);
                await stream.WriteAsync(body, ct);
            }
            catch { }
        }
    }

    private static string BuildHtml(string host, string category, string message)
    {
        var enc = HtmlEncoder.Default;
        return $$"""
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Blocked by WinGuard</title>
<style>
  :root { color-scheme: light dark; }
  * { box-sizing: border-box; }
  body { margin:0; min-height:100vh; display:grid; place-items:center; font-family:Segoe UI,Arial,sans-serif; background:#111827; color:#f9fafb; }
  main { width:min(620px,92vw); text-align:center; background:#1f2937; border:1px solid #374151; border-radius:24px; padding:38px 28px; box-shadow:0 20px 70px #0008; }
  .cat { font:700 64px/1 monospace; margin-bottom:14px; }
  h1 { margin:0 0 10px; font-size:clamp(28px,6vw,46px); }
  .message { font-size:22px; font-weight:700; margin:12px 0 24px; }
  .site { overflow-wrap:anywhere; padding:12px; border-radius:12px; background:#111827; margin:14px 0; }
  .small { opacity:.75; font-size:14px; }
  button { margin-top:18px; border:0; border-radius:999px; padding:11px 18px; font:600 15px Segoe UI,Arial,sans-serif; cursor:pointer; }
</style>
</head>
<body>
<main>
  <div class="cat">/\_/\\<br>( o.o )<br>&gt; ^ &lt;</div>
  <h1>Nice try 😹</h1>
  <div class="message">{{enc.Encode(message)}}</div>
  <div class="site">{{enc.Encode(host)}}</div>
  <div class="small">Blocked by WinGuard Agent · {{enc.Encode(category)}}</div>
  <button onclick="history.back()">Go back</button>
</main>
</body>
</html>
""";
    }
}
