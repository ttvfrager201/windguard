using Microsoft.Data.Sqlite;

namespace WinGuardAgent.Storage;

public sealed class PolicyRepository(Database db)
{
    public async Task AddDomainAsync(string domain, bool allowed, PolicyCategory category = PolicyCategory.Custom, string source = "local")
    {
        domain = NormalizeDomain(domain);
        await using var c = await db.OpenAsync();
        await using var cmd = c.CreateCommand();
        cmd.CommandText = "INSERT INTO BlockedDomains(Domain,IsAllowed,Category,Enabled,Source,UpdatedUtc) VALUES($d,$a,$c,1,$s,$u) ON CONFLICT(Domain,IsAllowed) DO UPDATE SET Category=$c,Enabled=1,Source=$s,UpdatedUtc=$u";
        cmd.Parameters.AddWithValue("$d", domain); cmd.Parameters.AddWithValue("$a", allowed ? 1 : 0); cmd.Parameters.AddWithValue("$c", category.ToString()); cmd.Parameters.AddWithValue("$s", source); cmd.Parameters.AddWithValue("$u", DateTimeOffset.UtcNow.ToString("O"));
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task RemoveDomainAsync(string domain, bool allowed)
    {
        domain = NormalizeDomain(domain);
        await using var c = await db.OpenAsync();
        await using var cmd = c.CreateCommand(); cmd.CommandText = "DELETE FROM BlockedDomains WHERE Domain=$d AND IsAllowed=$a"; cmd.Parameters.AddWithValue("$d", domain); cmd.Parameters.AddWithValue("$a", allowed ? 1 : 0); await cmd.ExecuteNonQueryAsync();
    }

    public async Task<IReadOnlyList<DomainRule>> GetDomainRulesAsync()
    {
        var list = new List<DomainRule>(); await using var c = await db.OpenAsync(); await using var cmd = c.CreateCommand(); cmd.CommandText = "SELECT Id,Domain,IsAllowed,Category,Enabled,Source FROM BlockedDomains WHERE Enabled=1"; await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync()) list.Add(new(r.GetInt64(0), r.GetString(1), r.GetInt32(2)!=0, Enum.TryParse<PolicyCategory>(r.GetString(3), out var cat)?cat:PolicyCategory.Custom, r.GetInt32(4)!=0, r.GetString(5)));
        return list;
    }

    public async Task AddApplicationAsync(string executable, string? path = null, string reason = "Administrator policy", PolicyCategory category = PolicyCategory.Custom)
    {
        executable = Path.GetFileName(executable.Trim()); if (string.IsNullOrWhiteSpace(executable)) throw new ArgumentException("Executable name is required.");
        await using var c = await db.OpenAsync(); await using var cmd = c.CreateCommand(); cmd.CommandText = "INSERT INTO BlockedApplications(ExecutableName,Path,Enabled,Reason,Category,UpdatedUtc) VALUES($e,$p,1,$r,$c,$u) ON CONFLICT(ExecutableName) DO UPDATE SET Path=$p,Enabled=1,Reason=$r,Category=$c,UpdatedUtc=$u"; cmd.Parameters.AddWithValue("$e", executable); cmd.Parameters.AddWithValue("$p", (object?)path ?? DBNull.Value); cmd.Parameters.AddWithValue("$r", reason); cmd.Parameters.AddWithValue("$c", category.ToString()); cmd.Parameters.AddWithValue("$u", DateTimeOffset.UtcNow.ToString("O")); await cmd.ExecuteNonQueryAsync();
    }

    public async Task RemoveApplicationAsync(string executable)
    {
        executable = Path.GetFileName(executable.Trim()); await using var c = await db.OpenAsync(); await using var cmd = c.CreateCommand(); cmd.CommandText = "DELETE FROM BlockedApplications WHERE ExecutableName=$e"; cmd.Parameters.AddWithValue("$e", executable); await cmd.ExecuteNonQueryAsync();
    }

    public async Task<IReadOnlyList<ApplicationRule>> GetApplicationRulesAsync()
    {
        var list = new List<ApplicationRule>(); await using var c=await db.OpenAsync(); await using var cmd=c.CreateCommand(); cmd.CommandText="SELECT Id,ExecutableName,Path,Enabled,Reason,Category FROM BlockedApplications WHERE Enabled=1"; await using var r=await cmd.ExecuteReaderAsync(); while(await r.ReadAsync()) list.Add(new(r.GetInt64(0),r.GetString(1),r.IsDBNull(2)?null:r.GetString(2),r.GetInt32(3)!=0,r.GetString(4),Enum.TryParse<PolicyCategory>(r.GetString(5),out var cat)?cat:PolicyCategory.Custom)); return list;
    }

    public static string NormalizeDomain(string input)
    {
        input=input.Trim().TrimEnd('.').ToLowerInvariant();
        if (Uri.TryCreate(input.Contains("://")?input:"https://"+input, UriKind.Absolute, out var u)) input=u.IdnHost;
        if (input.StartsWith("*.")) input=input[2..];
        if (input.Contains('/') || input.Contains(' ') || !input.Contains('.')) throw new ArgumentException("Enter a valid domain, for example example.com.");
        return input;
    }
}
