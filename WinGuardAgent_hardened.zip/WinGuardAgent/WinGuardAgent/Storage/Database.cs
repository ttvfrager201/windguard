using Microsoft.Data.Sqlite;

namespace WinGuardAgent.Storage;

public sealed class Database
{
    private readonly SemaphoreSlim _initGate = new(1, 1);
    private bool _initialized;
    public string ConnectionString => new SqliteConnectionStringBuilder { DataSource = Paths.Database, Mode = SqliteOpenMode.ReadWriteCreate, Cache = SqliteCacheMode.Shared }.ToString();

    public async Task InitializeAsync(CancellationToken ct = default)
    {
        if (_initialized) return;
        await _initGate.WaitAsync(ct);
        try
        {
            if (_initialized) return;
            Directory.CreateDirectory(Paths.ProgramData);
            Directory.CreateDirectory(Paths.LogDirectory);
            await using var c = new SqliteConnection(ConnectionString);
            await c.OpenAsync(ct);
            var sql = Schema.Sql;
            await using var cmd = c.CreateCommand();
            cmd.CommandText = sql;
            await cmd.ExecuteNonQueryAsync(ct);
            await using var pragma = c.CreateCommand();
            pragma.CommandText = "PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;";
            await pragma.ExecuteNonQueryAsync(ct);
            _initialized = true;
        }
        finally { _initGate.Release(); }
    }

    public async Task<SqliteConnection> OpenAsync(CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        var c = new SqliteConnection(ConnectionString);
        await c.OpenAsync(ct);
        return c;
    }
}

internal static class Schema
{
    public const string Sql = """
CREATE TABLE IF NOT EXISTS Policies (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL UNIQUE, Enabled INTEGER NOT NULL DEFAULT 1, Json TEXT NOT NULL, UpdatedUtc TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS BlockedDomains (Id INTEGER PRIMARY KEY AUTOINCREMENT, Domain TEXT NOT NULL COLLATE NOCASE, IsAllowed INTEGER NOT NULL DEFAULT 0, Category TEXT NOT NULL, Enabled INTEGER NOT NULL DEFAULT 1, Source TEXT NOT NULL DEFAULT 'local', UpdatedUtc TEXT NOT NULL, UNIQUE(Domain, IsAllowed));
CREATE INDEX IF NOT EXISTS IX_BlockedDomains_Domain ON BlockedDomains(Domain);
CREATE TABLE IF NOT EXISTS BlockedApplications (Id INTEGER PRIMARY KEY AUTOINCREMENT, ExecutableName TEXT NOT NULL COLLATE NOCASE, Path TEXT NULL, Enabled INTEGER NOT NULL DEFAULT 1, Reason TEXT NOT NULL DEFAULT 'Administrator policy', Category TEXT NOT NULL DEFAULT 'Custom', UpdatedUtc TEXT NOT NULL, UNIQUE(ExecutableName));
CREATE TABLE IF NOT EXISTS Events (Id INTEGER PRIMARY KEY AUTOINCREMENT, TimestampUtc TEXT NOT NULL, Type TEXT NOT NULL, Username TEXT NULL, Subject TEXT NULL, Reason TEXT NULL, MetadataJson TEXT NULL);
CREATE INDEX IF NOT EXISTS IX_Events_Timestamp ON Events(TimestampUtc DESC);
CREATE TABLE IF NOT EXISTS InstalledApplications (AppKey TEXT PRIMARY KEY, Name TEXT NOT NULL, Publisher TEXT NULL, Version TEXT NULL, InstallTimestampUtc TEXT NULL, Path TEXT NULL, FirstSeenUtc TEXT NOT NULL, LastSeenUtc TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS AgentSettings (Key TEXT PRIMARY KEY, Value TEXT NOT NULL, UpdatedUtc TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS AgentStatus (SingletonId INTEGER PRIMARY KEY CHECK(SingletonId=1), State TEXT NOT NULL, Version TEXT NOT NULL, LastHeartbeatUtc TEXT NOT NULL, LastError TEXT NULL);
INSERT OR IGNORE INTO AgentSettings(Key, Value, UpdatedUtc) VALUES ('schema_version','1',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
""";
}
