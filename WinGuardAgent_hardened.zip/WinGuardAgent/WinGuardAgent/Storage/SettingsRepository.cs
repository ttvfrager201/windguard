using System.Text.Json;
using System.Text.Json.Serialization;

namespace WinGuardAgent.Storage;

public sealed class SettingsRepository(Database db)
{
    private readonly JsonSerializerOptions _json = CreateJson();
    private static JsonSerializerOptions CreateJson() { var o=new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented=true }; o.Converters.Add(new JsonStringEnumConverter()); return o; }

    public async Task<AgentConfig> GetConfigAsync()
    {
        await using var c=await db.OpenAsync(); await using var cmd=c.CreateCommand(); cmd.CommandText="SELECT Value FROM AgentSettings WHERE Key='agent_config'"; var v=await cmd.ExecuteScalarAsync();
        if (v is string s) return JsonSerializer.Deserialize<AgentConfig>(s,_json) ?? new AgentConfig();
        var cfg=new AgentConfig(); await SaveConfigAsync(cfg); return cfg;
    }

    public async Task SaveConfigAsync(AgentConfig cfg)
    {
        var json=JsonSerializer.Serialize(cfg,_json); await using var c=await db.OpenAsync(); await using var cmd=c.CreateCommand(); cmd.CommandText="INSERT INTO AgentSettings(Key,Value,UpdatedUtc) VALUES('agent_config',$v,$u) ON CONFLICT(Key) DO UPDATE SET Value=$v,UpdatedUtc=$u"; cmd.Parameters.AddWithValue("$v",json); cmd.Parameters.AddWithValue("$u",DateTimeOffset.UtcNow.ToString("O")); await cmd.ExecuteNonQueryAsync();
        Directory.CreateDirectory(Paths.ProgramData); await File.WriteAllTextAsync(Paths.ConfigFile,json);
    }
}
