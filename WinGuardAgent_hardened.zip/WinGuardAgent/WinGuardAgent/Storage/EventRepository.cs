using Microsoft.Data.Sqlite;

namespace WinGuardAgent.Storage;

public sealed class EventRepository(Database db)
{
    public async Task WriteAsync(string type, string? username=null, string? subject=null, string? reason=null, string? metadataJson=null)
    {
        try
        {
            await using var c=await db.OpenAsync(); await using var cmd=c.CreateCommand(); cmd.CommandText="INSERT INTO Events(TimestampUtc,Type,Username,Subject,Reason,MetadataJson) VALUES($t,$y,$u,$s,$r,$m)";
            cmd.Parameters.AddWithValue("$t",DateTimeOffset.UtcNow.ToString("O")); cmd.Parameters.AddWithValue("$y",type); cmd.Parameters.AddWithValue("$u",(object?)username??DBNull.Value); cmd.Parameters.AddWithValue("$s",(object?)subject??DBNull.Value); cmd.Parameters.AddWithValue("$r",(object?)reason??DBNull.Value); cmd.Parameters.AddWithValue("$m",(object?)metadataJson??DBNull.Value); await cmd.ExecuteNonQueryAsync();
        } catch { }
    }

    public async Task<IReadOnlyList<AgentEvent>> RecentAsync(int limit=100)
    {
        var list=new List<AgentEvent>(); await using var c=await db.OpenAsync(); await using var cmd=c.CreateCommand(); cmd.CommandText="SELECT Id,TimestampUtc,Type,Username,Subject,Reason,MetadataJson FROM Events ORDER BY Id DESC LIMIT $n"; cmd.Parameters.AddWithValue("$n",Math.Clamp(limit,1,1000)); await using var r=await cmd.ExecuteReaderAsync();
        while(await r.ReadAsync()) list.Add(new(r.GetInt64(0),DateTimeOffset.Parse(r.GetString(1)),r.GetString(2),r.IsDBNull(3)?null:r.GetString(3),r.IsDBNull(4)?null:r.GetString(4),r.IsDBNull(5)?null:r.GetString(5),r.IsDBNull(6)?null:r.GetString(6)));
        return list;
    }
}
