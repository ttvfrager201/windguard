namespace WinGuardAgent.Storage;

public sealed class AgentStatusRepository(Database db)
{
    public async Task SetAsync(string state, string? error=null)
    {
        await using var c=await db.OpenAsync(); await using var cmd=c.CreateCommand();
        cmd.CommandText="INSERT INTO AgentStatus(SingletonId,State,Version,LastHeartbeatUtc,LastError) VALUES(1,$s,$v,$t,$e) ON CONFLICT(SingletonId) DO UPDATE SET State=$s,Version=$v,LastHeartbeatUtc=$t,LastError=$e";
        cmd.Parameters.AddWithValue("$s",state); cmd.Parameters.AddWithValue("$v",typeof(AgentStatusRepository).Assembly.GetName().Version?.ToString()??"unknown"); cmd.Parameters.AddWithValue("$t",DateTimeOffset.UtcNow.ToString("O")); cmd.Parameters.AddWithValue("$e",(object?)error??DBNull.Value); await cmd.ExecuteNonQueryAsync();
    }

    public async Task<(string State,string Version,DateTimeOffset Heartbeat,string? Error)?> GetAsync()
    {
        await using var c=await db.OpenAsync(); await using var cmd=c.CreateCommand(); cmd.CommandText="SELECT State,Version,LastHeartbeatUtc,LastError FROM AgentStatus WHERE SingletonId=1"; await using var r=await cmd.ExecuteReaderAsync(); if(!await r.ReadAsync()) return null; return (r.GetString(0),r.GetString(1),DateTimeOffset.Parse(r.GetString(2)),r.IsDBNull(3)?null:r.GetString(3));
    }
}
