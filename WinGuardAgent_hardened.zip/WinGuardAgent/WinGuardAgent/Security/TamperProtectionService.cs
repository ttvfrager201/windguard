using Microsoft.Extensions.Logging;
using WinGuardAgent.Chrome;
using WinGuardAgent.Network;
using WinGuardAgent.Storage;

namespace WinGuardAgent.Security;

public sealed class TamperProtectionService(
    NetworkProtectionManager network,
    ChromePolicyManager browsers,
    EventRepository events,
    ILogger<TamperProtectionService> log)
{
    public async Task VerifyAndRepairAsync(AgentConfig cfg)
    {
        if(!cfg.TamperProtectionEnabled) return;

        if(cfg.LockSystemProxy && !network.ProxyProtectionAppearsIntact())
        {
            network.ApplyProxyProtection();
            await events.WriteAsync("tamper_detected",subject:"proxy",reason:"Proxy settings changed; administrator policy restored");
            log.LogWarning("WinGuard restored modified proxy settings.");
        }

        if(cfg.DnsProtectionEnabled)
        {
            try
            {
                if(!await NetworkProtectionManager.IsLoopbackDnsConfiguredAsync())
                {
                    await NetworkProtectionManager.ConfigureLoopbackDnsAsync(true);
                    await events.WriteAsync("tamper_detected",subject:"dns",reason:"DNS settings changed; WinGuard loopback DNS restored");
                    log.LogWarning("WinGuard restored modified DNS settings.");
                }
            }
            catch(Exception ex)
            {
                log.LogWarning(ex,"Could not verify DNS configuration.");
                await events.WriteAsync("enforcement_error",subject:"dns",reason:"Could not verify DNS configuration");
            }
        }

        if(cfg.ChromePoliciesEnabled && !browsers.CorePoliciesAppearIntact(cfg))
        {
            await browsers.ApplyAsync(cfg,writeAudit:false);
            await events.WriteAsync("tamper_detected",subject:"browser_policy",reason:"Chrome/Edge machine policy changed; administrator policy restored");
            log.LogWarning("WinGuard restored modified browser policies.");
        }
    }
}
