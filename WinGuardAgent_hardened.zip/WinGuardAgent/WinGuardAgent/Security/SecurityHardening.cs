using System.Security.AccessControl;
using System.Security.Principal;

namespace WinGuardAgent.Security;

public sealed class SecurityHardening
{
    public void EnsureProgramDataAcl()
    {
        Directory.CreateDirectory(Paths.ProgramData);
        var info=new DirectoryInfo(Paths.ProgramData);
        var security=new DirectorySecurity();
        security.SetAccessRuleProtection(isProtected:true,preserveInheritance:false);
        var admins=new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null);
        var system=new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null);
        var users=new SecurityIdentifier(WellKnownSidType.BuiltinUsersSid,null);
        security.AddAccessRule(new FileSystemAccessRule(admins,FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
        security.AddAccessRule(new FileSystemAccessRule(system,FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
        security.AddAccessRule(new FileSystemAccessRule(users,FileSystemRights.ReadAndExecute,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
        info.SetAccessControl(security);
    }

    public static bool IsAdministrator()
    {
        using var id=WindowsIdentity.GetCurrent(); return new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator);
    }
}
